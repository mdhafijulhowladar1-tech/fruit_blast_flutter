import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const FruitApp());

class FruitApp extends StatelessWidget {
  const FruitApp({super.key});
  @override
  Widget build(BuildContext context) => const MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '8 Sec Fruit Blast',
        home: GamePage(),
      );
}

class Fruit {
  final String name, e;
  const Fruit(this.name, this.e);
}

const fruits = [
  Fruit('Mango', '🥭'), Fruit('Banana', '🍌'), Fruit('Apple', '🍎'),
  Fruit('Orange', '🍊'), Fruit('Grapes', '🍇'), Fruit('Strawberry', '🍓'),
  Fruit('Pineapple', '🍍'), Fruit('Watermelon', '🍉'), Fruit('Lemon', '🍋'),
  Fruit('Guava', '🍐'), Fruit('Jackfruit', '🍈'), Fruit('Lychee', '🍒'),
  Fruit('Papaya', '🥑'), Fruit('Coconut', '🥥'), Fruit('Kiwi', '🥝'),
  Fruit('Peach', '🍑'), Fruit('Blueberry', '🫐'), Fruit('Amla', '🍏'),
  Fruit('Star Fruit', '⭐'), Fruit('Olive', '🫒'), Fruit('Dragon', '🐲'),
  Fruit('Jamun', '🫐'), Fruit('Dates', '🍇'), Fruit('Malta', '🍊'),
];

class CardData {
  final int pairId;
  Fruit fruit;
  bool matched = false, open = false;
  CardData(this.pairId, this.fruit);
}

class GamePage extends StatefulWidget {
  const GamePage({super.key});
  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final rnd = Random();
  List<CardData> cards = [];
  CardData? first;
  bool lock = false, soundOn = true;
  int score = 0, timeLeft = 8, gameId = 0;
  String msg = 'Remember the cards!';
  Timer? timer;

  @override
  void initState() {
    super.initState();
    startGame();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void click() {
    if (soundOn) SystemSound.play(SystemSoundType.click);
  }

  void startGame() {
    timer?.cancel();
    final id = ++gameId;
    final picked = ([...fruits]..shuffle(rnd)).take(8).toList();
    cards = [];
    for (int i = 0; i < picked.length; i++) {
      cards.add(CardData(i, picked[i]));
      cards.add(CardData(i, picked[i]));
    }
    cards.shuffle(rnd);
    for (final c in cards) {
      c.open = true;
    }
    setState(() {
      score = 0;
      timeLeft = 8;
      first = null;
      lock = true;
      msg = 'Memorize for 2 sec!';
    });
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (!mounted || id != gameId) return;
      setState(() {
        for (final c in cards) {
          if (!c.matched) c.open = false;
        }
        lock = false;
        msg = 'Now Match!';
      });
    });
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        timeLeft--;
        if (timeLeft <= 2 && timeLeft > 0) {
          click();
          HapticFeedback.mediumImpact();
        }
        if (timeLeft <= 0) {
          autoChange();
          timeLeft = 8;
        }
      });
    });
  }

  void flip(int idx) {
    if (lock) return;
    final c = cards[idx];
    if (c.open || c.matched) return;
    click();
    HapticFeedback.selectionClick();
    setState(() => c.open = true);
    if (first == null) {
      first = c;
      return;
    }
    final f = first!;
    if (f.pairId == c.pairId) {
      setState(() {
        f.matched = true;
        c.matched = true;
        score += 10;
        msg = '✅ Matched! ${c.fruit.name} +10';
        first = null;
      });
      HapticFeedback.heavyImpact();
      if (cards.every((x) => x.matched)) {
        timer?.cancel();
        Future.delayed(const Duration(milliseconds: 600), showWin);
      }
    } else {
      lock = true;
      setState(() {
        score = max(0, score - 2);
        msg = '❌ Not Matched! -2';
      });
      HapticFeedback.vibrate();
      final id = gameId;
      Future.delayed(const Duration(milliseconds: 650), () {
        if (!mounted || id != gameId) return;
        setState(() {
          f.open = false;
          c.open = false;
          first = null;
          lock = false;
        });
      });
    }
  }

  void autoChange() {
    click();
    HapticFeedback.vibrate();
    final unmatched = cards.where((c) => !c.matched).toList();
    final ids = unmatched.map((c) => c.pairId).toSet().toList();
    final nf = ([...fruits]..shuffle(rnd)).take(ids.length).toList();
    for (int i = 0; i < ids.length; i++) {
      for (final c in unmatched) {
        if (c.pairId == ids[i]) {
          c.fruit = nf[i];
          c.open = false;
        }
      }
    }
    final matched = cards.where((c) => c.matched).toList();
    unmatched.shuffle(rnd);
    cards = [...matched, ...unmatched]..shuffle(rnd);
    first = null;
    lock = false;
    msg = '🔄 Images + Positions Changed!';
  }

  void showWin() {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('🎉 You Win!'),
        content: Text('Score: $score'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              startGame();
            },
            child: const Text('Play Again'),
          )
        ],
      ),
    );
  }

  Widget glass({required Widget child, EdgeInsets? pad}) => Container(
        constraints: const BoxConstraints(maxWidth: 400),
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: pad ?? const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35)),
        ),
        child: child,
      );

  @override
  Widget build(BuildContext context) {
    final shake = timeLeft <= 2 && timeLeft > 0;
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2), Color(0xFFF093FB), Color(0xFFF5576C)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(10),
            child: Center(
              child: Column(
                children: [
                  glass(
                    child: const Center(
                      child: Text('🍎 8 Sec Fruit Blast 🍌',
                          style: TextStyle(fontSize: 24, color: Colors.white)),
                    ),
                  ),
                  glass(
                    child: Column(children: [
                      Text('Score: $score',
                          style: const TextStyle(fontSize: 17, color: Colors.white, fontWeight: FontWeight.bold)),
                      Text('Next Change: $timeLeft sec',
                          style: const TextStyle(fontSize: 26, color: Color(0xFFFFE600), fontWeight: FontWeight.bold)),
                      Text(msg, style: const TextStyle(fontSize: 16, color: Colors.white)),
                    ]),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    transform: Matrix4.translationValues(shake ? (timeLeft.isEven ? -6 : 6) : 0, 0, 0),
                    child: glass(
                      pad: const EdgeInsets.all(12),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: cards.length,
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                          mainAxisSpacing: 10,
                          crossAxisSpacing: 10,
                        ),
                        itemBuilder: (_, i) => FlipCard(card: cards[i], onTap: () => flip(i)),
                      ),
                    ),
                  ),
                  Wrap(spacing: 10, children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFCC00), foregroundColor: Colors.black87),
                      onPressed: startGame,
                      child: const Text('🔄 New Game'),
                    ),
                    ElevatedButton(
                      onPressed: () => setState(() => soundOn = !soundOn),
                      child: Text(soundOn ? '🔊 Sound: ON' : '🔇 Sound: OFF'),
                    ),
                  ]),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class FlipCard extends StatelessWidget {
  final CardData card;
  final VoidCallback onTap;
  const FlipCard({super.key, required this.card, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final show = card.open || card.matched;
    return GestureDetector(
      onTap: onTap,
      child: TweenAnimationBuilder<double>(
        tween: Tween(end: show ? pi : 0),
        duration: const Duration(milliseconds: 500),
        builder: (_, v, __) {
          final isFront = v > pi / 2;
          return Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(v),
            child: isFront
                ? Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.rotationY(pi),
                    child: _front(),
                  )
                : _back(),
          );
        },
      ),
    );
  }

  Widget _back() => Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.25),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withOpacity(0.5)),
        ),
        alignment: Alignment.center,
        child: const Text('❓', style: TextStyle(fontSize: 34)),
      );

  Widget _front() => Container(
        decoration: BoxDecoration(
          color: card.matched ? const Color(0xFFE8F5E9) : Colors.white,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(card.fruit.e, style: const TextStyle(fontSize: 34)),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(color: const Color(0xFFFFE600), borderRadius: BorderRadius.circular(10)),
              child: Text(card.fruit.name,
                  style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.black87),
                  overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      );
}
